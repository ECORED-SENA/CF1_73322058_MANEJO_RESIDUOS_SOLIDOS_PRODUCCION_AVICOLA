function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6107vynw5vU":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

